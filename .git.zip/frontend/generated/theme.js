import {applyTheme as _applyTheme} from './theme-torneos-theme.generated.js';
export const applyTheme = _applyTheme;
